#include "graph_interface.h"

using namespace std;


namespace GRAPH {
    Vertex::Vertex(double tx, double ty, double rotate) {
        this->position[0] = tx;
        this->position[1] = ty;
        this->position[2] = rotate;
    }

    Vertex::Vertex(double *p) {
        copy(p, p + 3, this->position);
    }

    Vertex::Vertex(const Vertex &other) {
        copy(other.position, other.position + 3, this->position);
    }

    Vertex &Vertex::operator=(const Vertex &other) {
        copy(other.position, other.position + 3, this->position);
        return *this;
    }

    LaserData::LaserData(int id, int *data, char *flag, double yaw, double *relative, double *global)
        : data(new int[NUMBER_OF_POINTS]), flag(new char[NUMBER_OF_POINTS]) {
        this->frame_id = id;
        copy(data, data + NUMBER_OF_POINTS, this->data);
        copy(flag, flag + NUMBER_OF_POINTS, this->flag);
        this->yaw = yaw;
        copy(relative, relative + 3, this->relativeTransfer);
        copy(global, global + 3, this->globalPosition);
    }

    LaserData::LaserData(const LaserData &other)
        : data(new int[NUMBER_OF_POINTS]), flag(new char[NUMBER_OF_POINTS]) {
        this->frame_id = other.frame_id;
        copy(other.data, other.data + NUMBER_OF_POINTS, this->data);
        copy(other.flag, other.flag + NUMBER_OF_POINTS, this->flag);
        this->yaw = other.yaw;
        copy(other.relativeTransfer, other.relativeTransfer + 3, this->relativeTransfer);
        copy(other.globalPosition, other.globalPosition + 3, this->globalPosition);
    }

    LaserData::~LaserData() {
        if (data != nullptr) delete[] data;
        if (flag != nullptr) delete[] flag;
    }

    LaserData &LaserData::operator=(const LaserData &other) {
        this->frame_id = other.frame_id;
        copy(other.data, other.data + NUMBER_OF_POINTS, this->data);
        copy(other.flag, other.flag + NUMBER_OF_POINTS, this->flag);
        copy(other.relativeTransfer, other.relativeTransfer + 3, this->relativeTransfer);
        return *this;
    }

    void LaserData::releaseData() {
        if (data != nullptr) {
            delete[] data;
            data = nullptr;
        }
        if (flag != nullptr) {
            delete[] flag;
            flag = nullptr;
        }
    }

    Edge::Edge(int id_to, int id_from, double tx, double ty, double rotate) {
        this->id_to = id_to;
        this->id_from = id_from;
        this->transfer[0] = tx;
        this->transfer[1] = ty;
        this->transfer[2] = rotate;
    }

    Edge::Edge(int id_to, int id_from, double *p) {
        this->id_to = id_to;
        this->id_from = id_from;
        copy(p, p + 3, this->transfer);
    }

    Edge::Edge(const Edge &other) {
        this->id_to = other.id_to;
        this->id_from = other.id_from;
        copy(other.transfer, other.transfer + 3, this->transfer);
    }

    Edge &Edge::operator=(const Edge &other) {
        this->id_to = other.id_to;
        this->id_from = other.id_from;
        copy(other.transfer, other.transfer + 3, this->transfer);
        return *this;
    }

    template<typename V, typename E, typename LD>
    void GraphInterface<V, E, LD>::updatePosition() {
        auto end = key_frames.end() - 1;
        for (auto it = key_frames.begin() + lastOpti; it != end; ++it) {
            auto next = it + 1;
            double new_angle = it->globalPosition[2] + next->relativeTransfer[2];
            double c = cos(new_angle);
            double s = sin(new_angle);
            double new_x = next->relativeTransfer[0] + c * it->globalPostion[0] - s * it->globalPostion[1];
            double new_y = next->relativeTransfer[1] + s * it->globalPostion[0] + c * it->globalPostion[1];
            next->globalPostion[0] = new_x;
            next->globalPostion[1] = new_y;
            next->globalPostion[2] = new_angle;
        }
    }

    template<typename V, typename E, typename LD>
    void GraphInterface<V, E, LD>::beginToOptimize(unique_vertex &pVertex, unique_edge &pEdge) {
        int end = key_frames.end();
        for (int i = lastOpti; i < end - 3; ++i) {
            add_edge(i, i + 3);
        }

        pVertex = move(graph_vertexs);
        graph_vertexs = new vertexs;
        pEdge = move(graph_edges);
        graph_edges = new edges;

        lastOpti = key_frames.end() - key_frames.begin() - 1;
    }

    template<typename V = Vertex, typename E = Edge, typename LD = LaserData>
    GraphInterface<V, E, LD> &getInstance() {
        static GraphInterface<V, E, LD> instance;
        return instance;
    }
}