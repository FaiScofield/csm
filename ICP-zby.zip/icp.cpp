#include "icp.h"

using namespace std;

int main() {
    system("pause");
    return 0;
    PREPARE_TIME_VARIABLE;
    int whichToRead = 21;
    int numOfFiles[]{ 1259,266,470,832,386,239,488,360,1281,0,0,0,1489,1536,2253,1658,583,522,932,924,2999 };
    string dir_name = "../laser/laser" + to_string(whichToRead) + "/";
    //string dir_name = "../a/";
    ICP::TransformVector global_tv, current_tv;
    ofstream ofs("out.txt");
    //for (int idx = 1; idx < 226; idx += 1) {
    for (int idx = 1; idx < numOfFiles[whichToRead - 1]; idx += 1) {
        string name = dir_name + to_string(idx) + ".txt";
        double initRotate;
        vector<ICP::Point> data = ICP::readFile(name, &initRotate);
        double initR = initRotate / 18000.0f * M_PI;
        START_CLOCK;
        current_tv = ICP::wayCai::match2Frames(data, initR);
        END_CLOCK;
        PRINT_TIME_LENGTH;
        //printf_s("%d: dx=%.6f dy=%.6f dtheta=%f ga=%f\n", idx, current_tv.tx, current_tv.ty, current_tv.rotate, global_tv.rotate);
        global_tv = current_tv * global_tv;
        auto p = global_tv.getInplaceInverse();
        ofs << p.tx << " " << p.ty << "\n";
    }
    ofs.close();
    global_tv = global_tv.getInplaceInverse();
    //printf_s("gx=%.3f, gy=%.3f, gtheta=%.6f\n", global_tv.tx, global_tv.ty, global_tv.rotate);
    system("pause");
    return 0;
}


#ifdef ICP_WRITE_TO_FILE
int file_count = 0;
#endif // ICP_WRITE_TO_FILE


namespace ICP {


    TransformVector::TransformVector(double tx, double ty, double rotate) : tx(tx), ty(ty), rotate(rotate) {};

    TransformVector::TransformVector(double *p) : tx(p[0]), ty(p[1]), rotate(p[2]) {};

    TransformVector::TransformVector(const Eigen::Matrix3d &m) : tx(m(0, 2)), ty(m(1, 2)), rotate(atan2(m(1, 0), m(0, 0))) {};

    TransformVector TransformVector::getInverse() const {
        return TransformVector{ cos(rotate)*tx + sin(rotate)*ty,cos(rotate)*ty - sin(rotate)*tx,-rotate };
    }

    TransformVector TransformVector::getInplaceInverse() const {
        return TransformVector{ -cos(rotate)*tx - sin(rotate)*ty,-cos(rotate)*ty + sin(rotate)*tx,-rotate };
    }

    void TransformVector::toDoubleVector(double *v) {
        v[0] = tx;
        v[1] = ty;
        v[2] = rotate;
    }

    Eigen::Matrix3d TransformVector::toEigenMatrix() {
        Eigen::Matrix3d m;
        double c = cos(rotate);
        double s = sin(rotate);
        m << c, -s, tx, s, c, ty, 0, 0, 1;
        return m;
    }

    double TransformVector::movementSquared() {
        return tx * tx + ty * ty;
    }

    void TransformVector::inverse() {
        double tmp_x = cos(rotate) * tx + sin(rotate) * ty;
        double tmp_y = -sin(rotate) * tx + cos(rotate) * ty;
        tx = tmp_x;
        ty = tmp_y;
        rotate = -rotate;
    }

    bool TransformVector::isValidTransfer() {
        return rotate < 0.4 && (rotate != 0 || tx != 0 || ty != 0);
    }

    TransformVector TransformVector::operator+(const TransformVector &other) {
        double r = rotate + other.rotate;
        if (r > M_PI) r -= 2 * M_PI;
        if (r <= -M_PI) r += 2 * M_PI;
        return TransformVector{ tx + other.tx,ty + other.ty,r };
    }

    TransformVector &TransformVector::operator+=(const TransformVector &other) {
        tx += other.tx;
        ty += other.ty;
        rotate += other.rotate;
        if (rotate > M_PI) rotate -= 2 * M_PI;
        if (rotate <= -M_PI) rotate += 2 * M_PI;
        return *this;
    }

    TransformVector TransformVector::operator*(const TransformVector &other) {
        double r = rotate + other.rotate;
        if (r > M_PI) r -= 2 * M_PI;
        if (r <= -M_PI) r += 2 * M_PI;
        return TransformVector{
            tx + other.tx * cos(rotate) - other.ty * sin(rotate),
            ty + other.tx * sin(rotate) + other.ty * cos(rotate),
            r
        };
    }

    Point::Point(double x, double y, int index, char flag) : x(x), y(y), index(index), flag(flag) {};

    Point::Point(double x, double y, bool flag) : x(x), y(y), index(-1), flag(flag ? 1 : 0) {};

    Point::Point(int r, int index, char flag) : index(index) {
        x = r * cos(POINT_ANGLE(index)) / 1000.0f;
        y = r * sin(POINT_ANGLE(index)) / 1000.0f;
        this->flag = (ICP_MIN_LASER_RANGE < r && r < ICP_MAX_LASER_RANGE) ? flag : 0;
    }

    double Point::originDistance() {
        return sqrt(pow(x, 2) + pow(y, 2));
    }

    double Point::distance(const Point &p1, const Point &p2) {
        return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2));
    }

    double Point::distance(const pair<Point, Point> &pr) {
        return distance(pr.first, pr.second);
    }

    double Point::distanceSquared(const Point &p1, const Point &p2) {
        double x = p1.x - p2.x;
        double y = p1.y - p2.y;
        return x * x + y * y;
    }

    double Point::distanceSquared(const pair<Point, Point> &pr) {
        return distanceSquared(pr.first, pr.second);
    }

    double Point::getAngle() const {
        return POINT_ANGLE(index);
    }

    bool Point::operator==(const Point &other) {
        return index == other.index;
    }

    Point Point::operator+(const Point &other) {
        return Point(x + other.x, y + other.y, flag && other.flag);
    }

    Point &Point::operator+=(const Point &other) {
        x += other.x;
        y += other.y;
        flag = flag && other.flag ? 1 : 0;
        return *this;
    }

    Point Point::operator-(const Point &other) {
        return Point(x - other.x, y - other.y, flag && other.flag);
    }

    Point &Point::operator-=(const Point &other) {
        x -= other.x;
        y -= other.y;
        flag = flag && other.flag ? 1 : 0;
        return *this;
    }

    Point &Point::transfer(const TransformVector &t) {
        double tmp_x = x * cos(t.rotate) - y * sin(t.rotate) + t.tx;
        double tmp_y = x * sin(t.rotate) + y * cos(t.rotate) + t.ty;
        x = tmp_x;
        y = tmp_y;
        return *this;
    }

    void Point::inverseTransfer(const TransformVector &t) {
        transfer(t.getInverse());
    }

    Line::Line(double slope, double bias) :slope(slope), bias(bias) {};

    Line::Line(const Point &p1, const Point &p2) {
        slope = (p1.y - p2.y) / (p1.x - p2.x);
        bias = p1.y - slope * p1.x;
    }

    double Line::getPointDistance(const Point &p) {
        return abs(slope * p.x - p.y + bias) / sqrt(1 + slope * slope);
    }

    double Line::getAngle() {
        double angle = atan(slope);
        return angle > 0 ? angle : angle + M_PI;
    }

    vector<Point> readFile(string file_name, double *init_rotate) {
        ifstream file{ file_name.c_str() };
        vector<Point> points;
        points.reserve(NUMBER_OF_POINTS);
        double a, x, y, r, rubbish;
        char flag;
        file >> x >> y >> rubbish >> a;
        //file >> a;
        if (init_rotate != nullptr) {
            *init_rotate = a;
        }
        for (int i = 0; i < NUMBER_OF_POINTS; i++) {
            file >> r >> flag >> a >> rubbish;
            points.push_back(Point(r * cos(POINT_ANGLE(i)) / 1000.0f,
                                   -r * sin(POINT_ANGLE(i)) / 1000.0f,
                                   i,
                                   (ICP_MIN_LASER_RANGE < r && r < ICP_MAX_LASER_RANGE) ? flag - '0' : 0));
        }
        file.close();
        return points;
    }

    CorPoints::CorPoints() : relation(vector<pair<Point, Point>>{}) {};

    CorPoints::CorPoints(const CorPoints &other) : relation(other.relation) {};

    CorPoints::CorPoints(CorPoints &&other) : relation(move(other.relation)) {};

    CorPoints &CorPoints::operator=(const CorPoints &other) {
        relation = other.relation;
        return *this;
    }

    CorPoints &CorPoints::operator=(CorPoints &&other) {
        if (this != &other) {
            relation = move(other.relation);
        }
        return *this;
    }

    CorPoints::CorPoints(vector<pair<Point, Point>> &&cor) : relation(cor) {};

    CorPoints::CorPoints(vector<pair<Point, Point>>::iterator start, vector<pair<Point, Point>>::iterator end) : relation(start, end) {};

    CorPoints::CorPoints(vector<Point> &vRef, vector<Point> &vNew, int distance) : relation() {
        int k;
        double tmp_min;
        double tmp_distance2;
        int tmp_idx = 0;
        int ref_size = vRef.size();
        int new_size = vNew.size();
        double distance_limit = distance * 0.04;
        for (int i = 0; i < ref_size; ++i) {
            if (vRef[i].flag != 1) continue;
            tmp_min = DBL_MAX;

            for (int j = -ICP_SEARCH_RANGE; j <= ICP_SEARCH_RANGE; ++j) {
                k = i + j;
                if (k < 0 || k >= new_size) continue;
                if (vNew[k].flag != 1) continue;
                tmp_distance2 = Point::distanceSquared(vRef[i], vNew[k]);
                if (tmp_distance2 < (tmp_min < distance_limit ? tmp_min : distance_limit)) {
                    tmp_idx = k;
                    tmp_min = tmp_distance2;
                }
            }

            if (tmp_min != DBL_MAX) {
                relation.emplace_back(vRef[i], vNew[tmp_idx]);
            }
        }
    }

    CorPoints CorPoints::removeDuplicate() {
        auto begin = relation.begin();
        auto end = relation.end();
        sort(begin, end, [](const pair<Point, Point> &a, const pair<Point, Point> &b) {
            return a.second.index < b.second.index || a.second.index == b.second.index && Point::distanceSquared(a) < Point::distanceSquared(b);
        });
        return CorPoints(begin, unique(begin, end, [](const pair<Point, Point> &a, const pair<Point, Point> &b) {
            return a.second.index == b.second.index; }));
    }

    TransformVector CorPoints::calcTransformVector() {
        if (relation.empty()) throw CAN_NOT_MAKE_PAIRS_ERROR();
        double sum_refX = 0;
        double sum_refY = 0;
        double sum_newX = 0;
        double sum_newY = 0;
        double sum_refX_newX = 0;
        double sum_refX_newY = 0;
        double sum_refY_newX = 0;
        double sum_refY_newY = 0;
        int length = relation.size();

        for (auto &pr : relation) {
            sum_refX += pr.first.x;
            sum_refY += pr.first.y;
            sum_newX += pr.second.x;
            sum_newY += pr.second.y;
            sum_refX_newX += pr.first.x * pr.second.x;
            sum_refX_newY += pr.first.x * pr.second.y;
            sum_refY_newX += pr.first.y * pr.second.x;
            sum_refY_newY += pr.first.y * pr.second.y;
        }
        sum_refX_newX -= sum_refX * sum_newX / length;
        sum_refX_newY -= sum_refX * sum_newY / length;
        sum_refY_newX -= sum_refY * sum_newX / length;
        sum_refY_newY -= sum_refY * sum_newY / length;

        double angle = atan2(sum_refX_newY - sum_refY_newX, sum_refX_newX + sum_refY_newY);
        double tx = sum_newX / length - (sum_refX / length * cos(angle) - sum_refY / length * sin(angle));
        double ty = sum_newY / length - (sum_refX / length * sin(angle) + sum_refY / length * cos(angle));
        return TransformVector(tx, ty, angle);
    }

    namespace wayCai {
        TransformVector match2Frames(int *data, char *flag) {
            vector<Point> vData;
            vData.reserve(NUMBER_OF_POINTS);
            for (int i = 0; i < NUMBER_OF_POINTS; ++i) {
                vData.emplace_back(data[i], i, flag[i]);
            }
            return match2Frames(vData);
        }

        TransformVector match2Frames(int *data, char *flag, double rotate) {
            vector<Point> vData;
            vData.reserve(NUMBER_OF_POINTS);
            for (int i = 0; i < NUMBER_OF_POINTS; ++i) {
                vData.emplace_back(data[i], i, flag[i]);
            }
            return match2Frames(vData, rotate);
        }

        TransformVector match2Frames(int *refData, char *refFlag, int *newData, char *newFlag, double rotate, int distance) {
            vector<Point> vRef, vNew;
            vRef.reserve(NUMBER_OF_POINTS);
            vNew.reserve(NUMBER_OF_POINTS);
            for (int i = 0; i < NUMBER_OF_POINTS; ++i) {
                vRef.emplace_back(refData[i], i, refFlag[i]);
                vNew.emplace_back(newData[i], i, newFlag[i]);
            }
            return match2Frames(vRef, vNew, TransformVector{ 0,0,rotate }, distance);
        }

        TransformVector match2Frames(vector<Point> &vRef, vector<Point> &vNew, TransformVector trans, int distance) {
            TransformVector add_trans = trans;
            try {
                for (int i = 0; i < 20; i++) {
                    for (auto &p : vRef) {
                        p.transfer(add_trans);
                    }
                    add_trans = CorPoints(vRef, vNew, distance).removeDuplicate().calcTransformVector();
                    trans = add_trans * trans;
                    if (add_trans.movementSquared() < 1e-10) {
                        break;
                    }
                }
                return trans;
            }
            catch (const exception &e) {
                cout << e.what() << endl;
                return TransformVector{ 0,0,0 };
            }
        }

        TransformVector match2Frames(vector<Point> &curData) {
            static vector<Point> preData;
            if (preData.size() == 0) {
                preData = move(curData);
                return TransformVector{ 0,0,0 };
            }
            static TransformVector init_trans{ 0,0,0 };
            TransformVector trans = match2Frames(preData, curData, init_trans);
            if (trans.isValidTransfer()) {
                init_trans = move(trans);
                preData = move(curData);
                return trans;
            }
            else {
                return TransformVector{ 0,0,0 };
            }
        }

        TransformVector match2Frames(vector<Point> &curData, double curRotate) {
            static vector<Point> preData;
            static double preRotate = 0;
            if (preData.size() == 0) {
                preRotate = curRotate;
                preData = move(curData);
                return TransformVector{ 0,0,0 };
            }
            TransformVector init_trans{ 0,0,curRotate - preRotate };
            TransformVector trans = match2Frames(preData, curData, init_trans);
            if (trans.isValidTransfer()) {
                preRotate = curRotate;
                preData = move(curData);
                return trans;
            }
            else {
                return TransformVector{ 0,0,0 };
            }
        }

        CaiGraphInterface::CaiGraphInterface() : GraphInterface() {};

        CaiGraphInterface &CaiGraphInterface::getInstance() {
            static CaiGraphInterface instance;
            return instance;
        }

        void CaiGraphInterface::add_edge(int frame_id_from, int frame_id_to) {
            auto trans = match2Frames(
                key_frames[frame_id_from].data,
                key_frames[frame_id_from].flag,
                key_frames[frame_id_to].data,
                key_frames[frame_id_to].flag,
                key_frames[frame_id_to].yaw - key_frames[frame_id_from].yaw,
                abs(frame_id_to - frame_id_from)).getInplaceInverse();
            double transform[3];
            if (trans.isValidTransfer()) {
                trans.toDoubleVector(transform);
                graph_edges->emplace_back(frame_id_from, frame_id_to, transform);
            }
        }

        int CaiGraphInterface::add_laserdata(int *data, char *flag, double yaw) {
            if (key_frames.empty()) {
                double p[3]{ 0,0,0 };
                key_frames.emplace_back(0, data, flag, yaw, p, p);
                match2Frames(data, flag, 0);
                graph_vertexs->emplace_back(0, 0, 0);
                return 0;
            }
            else {
                int id = key_frames.size();
                auto last_frame = key_frames.back();
                auto trans = match2Frames(data, flag, last_frame.yaw - yaw).getInplaceInverse();
                double relative[3];
                trans.toDoubleVector(relative);
                auto c = cos(relative[2]), s = sin(relative[2]);
                double global[3]{ 
                    relative[0] + c * last_frame.globalPosition[0] - s * last_frame.globalPosition[1],
                    relative[1] + s * last_frame.globalPosition[0] + c * last_frame.globalPosition[1],
                    relative[2] + last_frame.globalPosition[2] };
                key_frames.emplace_back(id, data, flag, yaw, relative, global);
                graph_vertexs->emplace_back(global);
                graph_edges->emplace_back(id - 1, id, relative);
            }
        }

    }

}
