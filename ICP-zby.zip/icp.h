#ifndef ICP_ICP_H
#define ICP_ICP_H
#include <bits/stdc++.h>
#include <Eigen/Core>
#include "graph_interface.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#ifdef _WIN32
#include <windows.h>
#define PREPARE_TIME_VARIABLE LARGE_INTEGER nFreq, nBeginTime, nEndTime
#define START_CLOCK do {QueryPerformanceFrequency(&nFreq); QueryPerformanceCounter(&nBeginTime);} while(0)
#define END_CLOCK QueryPerformanceCounter(&nEndTime)
#define PRINT_TIME_LENGTH printf("->%f us\n", 1000000 * (nEndTime.QuadPart - nBeginTime.QuadPart) / (double)nFreq.QuadPart)
#else
#include <sys/time.h>
#define PREPARE_TIME_VARIABLE struct timeval nBeginTime, nEndTime
#define START_CLOCK gettimeofday(&nBeginTime, NULL)
#define END_CLOCK gettimeofday(&nEndTime, NULL)
#define PRINT_TIME_LENGTH printf("->%ld us\n", 1000000 * (nEndTime.tv_sec - nBeginTime.tv_sec) + (nEndTime.tv_usec - nBeginTime.tv_usec))
#endif

//#define ICP_WRITE_TO_FILE

#define invMat3D(mat, inv) {\
double value =(mat)[0][0] * (mat)[1][1] * (mat)[2][2] + (mat)[0][1] * (mat)[1][2] * (mat)[2][0]\
+ (mat)[0][2] * (mat)[1][0] * (mat)[2][1]- (mat)[0][0] * (mat)[1][2] * (mat)[2][1] \
- (mat)[0][1] * (mat)[1][0] * (mat)[2][2] - (mat)[0][2] * (mat)[1][1] * (mat)[2][0]; \
assert((value) != 0); \
(inv)[0][0] = ((mat)[1][1] * (mat)[2][2] - (mat)[1][2] * (mat)[2][1]) / value; \
(inv)[0][1] = ((mat)[0][2] * (mat)[2][1] - (mat)[0][1] * (mat)[2][2]) / value; \
(inv)[0][2] = ((mat)[0][1] * (mat)[1][2] - (mat)[0][2] * (mat)[1][1]) / value; \
(inv)[1][0] = ((mat)[1][2] * (mat)[2][0] - (mat)[1][0] * (mat)[2][2]) / value; \
(inv)[1][1] = ((mat)[0][0] * (mat)[2][2] - (mat)[0][2] * (mat)[2][0]) / value; \
(inv)[1][2] = ((mat)[0][2] * (mat)[1][0] - (mat)[0][0] * (mat)[1][2]) / value; \
(inv)[2][0] = ((mat)[1][0] * (mat)[2][1] - (mat)[1][1] * (mat)[2][0]) / value; \
(inv)[2][1] = ((mat)[0][1] * (mat)[2][0] - (mat)[0][0] * (mat)[2][1]) / value; \
(inv)[2][2] = ((mat)[0][0] * (mat)[1][1] - (mat)[0][1] * (mat)[1][0]) / value; \
}

#define mat3Dmul(m1, m2, r) { \
(r)[0][0] = (m1)[0][0] * (m2)[0][0] + (m1)[0][1] * (m2)[1][0] + (m1)[0][2] * (m2)[2][0]; \
(r)[0][1] = (m1)[0][0] * (m2)[0][1] + (m1)[0][1] * (m2)[1][1] + (m1)[0][2] * (m2)[2][1]; \
(r)[0][2] = (m1)[0][0] * (m2)[0][2] + (m1)[0][1] * (m2)[1][2] + (m1)[0][2] * (m2)[2][2]; \
(r)[1][0] = (m1)[1][0] * (m2)[0][0] + (m1)[1][1] * (m2)[1][0] + (m1)[1][2] * (m2)[2][0]; \
(r)[1][1] = (m1)[1][0] * (m2)[0][1] + (m1)[1][1] * (m2)[1][1] + (m1)[1][2] * (m2)[2][1]; \
(r)[1][2] = (m1)[1][0] * (m2)[0][2] + (m1)[1][1] * (m2)[1][2] + (m1)[1][2] * (m2)[2][2]; \
(r)[2][0] = (m1)[2][0] * (m2)[0][0] + (m1)[2][1] * (m2)[1][0] + (m1)[2][2] * (m2)[2][0]; \
(r)[2][1] = (m1)[2][0] * (m2)[0][1] + (m1)[2][1] * (m2)[1][1] + (m1)[2][2] * (m2)[2][1]; \
(r)[2][2] = (m1)[2][0] * (m2)[0][2] + (m1)[2][1] * (m2)[1][2] + (m1)[2][2] * (m2)[2][2]; \
}

namespace ICP {

    constexpr auto ICP_SEARCH_RANGE = 50;
    constexpr auto NUMBER_OF_POINTS = 937;
    constexpr auto ICP_MAX_LASER_RANGE = 10000;
    constexpr auto ICP_MIN_LASER_RANGE = 500;
    constexpr auto LASER_THETA = M_PI / 720.0f;

    template<typename T>
    constexpr double POINT_ANGLE(T x) {
        return static_cast<double>(x - (NUMBER_OF_POINTS - 1) / 2) * LASER_THETA;
    }

    template<typename T>
    constexpr int POINT_INDEX(T x) {
        return static_cast<int>(x / LASER_THETA + (NUMBER_OF_POINTS - 1) / 2);
    }

    class TransformVector
    {
    public:
        explicit TransformVector(double tx = 0, double ty = 0, double rotate = 0);
        explicit TransformVector(double *p);
        explicit TransformVector(const Eigen::Matrix3d &m);
        double tx;
        double ty;
        double rotate;

        TransformVector getInverse() const;
        TransformVector getInplaceInverse() const; // inverse in the local coordinate but not the opposite coordinate
        TransformVector operator+(const TransformVector &other);
        TransformVector &operator+=(const TransformVector &other);
        TransformVector operator*(const TransformVector &other); // next * current
        void toDoubleVector(double *v);
        Eigen::Matrix3d toEigenMatrix();
        double movementSquared();
        void inverse();
        bool isValidTransfer();
    };

    class Point
    {
    public:
        explicit Point(double x = 0, double y = 0, int index = -1, char flag = 1);
        explicit Point(double x, double y, bool flag);
        explicit Point(int r, int index, char flag);
        Point(const Point &p) = default;
        Point &operator=(const Point &p) = default;
        ~Point() = default;
        double x;
        double y;
        int index;
        char flag;

        double originDistance();
        static double distance(const Point &p1, const Point &p2);
        static double distance(const std::pair<Point, Point> &pr);
        static double distanceSquared(const Point &p1, const Point &p2);
        static double distanceSquared(const std::pair<Point, Point> &pr);
        double getAngle() const;
        bool operator==(const Point &other);
        Point operator+(const Point &other);
        Point &operator+=(const Point &other);
        Point operator-(const Point &other);
        Point &operator-=(const Point &other);

        Point &transfer(const TransformVector &t);
        void inverseTransfer(const TransformVector &t);

    };

    std::vector<Point> readFile(std::string file_name, double *init_rotate = nullptr);

    class Line
    {
    public:
        Line(double slope, double bias);
        Line(const Point &p1, const Point &p2);
        ~Line() = default;
        double slope;
        double bias;

        double getPointDistance(const Point &p);
        double getAngle();
    };

    class CorPoints
    {
    public:
        CorPoints();
        CorPoints(const CorPoints &other);
        CorPoints(CorPoints &&other);
        CorPoints(std::vector<Point> &vRef, std::vector<Point> &vNew, int distance);
        CorPoints(std::vector<std::pair<Point, Point>> &&cor);
        CorPoints(std::vector<std::pair<Point, Point>>::iterator start, std::vector<std::pair<Point, Point>>::iterator end);
        ~CorPoints() = default;
        CorPoints &operator=(const CorPoints &other);
        CorPoints &operator=(CorPoints &&other);
        /* make_pair(ref_point, new_point) */
        std::vector<std::pair<Point, Point>> relation;

        CorPoints removeDuplicate();
        TransformVector calcTransformVector();
    };

    class CAN_NOT_MAKE_PAIRS_ERROR : public std::exception
    {
    public:
        CAN_NOT_MAKE_PAIRS_ERROR() : std::exception() {};
    };

    namespace wayCai {

        TransformVector match2Frames(int *data, char *flag);

        TransformVector match2Frames(int *data, char *flag, double rotate);

        TransformVector match2Frames(int *refData, char *refFlag, int *newData, char *newFlag, double rotate, int distance = 1);

        TransformVector match2Frames(std::vector<Point> &curData);

        TransformVector match2Frames(std::vector<Point> &curData, double curRotate);

        TransformVector match2Frames(std::vector<Point> &vRef, std::vector<Point> &vNew, TransformVector trans, int distance = 1);

        class CaiGraphInterface : public GRAPH::GraphInterface<GRAPH::Vertex, GRAPH::Edge, GRAPH::LaserData>
        {
        public:
            using base_type = GRAPH::GraphInterface<GRAPH::Vertex, GRAPH::Edge, GRAPH::LaserData>;

            CaiGraphInterface(const CaiGraphInterface &other) = delete;

            static CaiGraphInterface &getInstance();

            void add_edge(int frame_id_from, int frame_id_to);

            int add_laserdata(int *data, char *flag, double yaw);

        private:
            CaiGraphInterface();
        };

    }

}
#endif